"""Generate a realistic demo dataset.

    python manage.py seed_data            # seed if the database is empty
    python manage.py seed_data --reset    # wipe attendance data and re-seed

Creates 1 school, 3 terms, 6 classrooms (1 teacher each), 25-30 students per
class and ~90 school days of attendance per term. Most students follow a
90/5/3/2 (present/absent/late/excused) distribution; a few are deliberately
"problem" cases so the Insights page has something to flag.
"""
import random
from datetime import date, timedelta

from django.core.management.base import BaseCommand
from django.db import transaction

from attendance.models import (
    AcademicTerm,
    AttendanceRecord,
    ClassRoom,
    School,
    Student,
    Teacher,
)

S = AttendanceRecord.Status
STATUSES = [S.PRESENT, S.ABSENT, S.LATE, S.EXCUSED]

NORMAL = [90, 5, 3, 2]
GOOD = [94, 3, 2, 1]
AT_RISK = [68, 22, 6, 4]
DROPPED = [62, 28, 6, 4]

# (class name, grade level, weights for the class)
CLASSES = [
    ("Grade 3A", 3, NORMAL),
    ("Grade 3B", 3, NORMAL),
    ("Grade 4A", 4, NORMAL),
    ("Grade 4B", 4, NORMAL),
    ("Grade 5A", 5, [84, 10, 4, 2]),  # weaker class
    ("Grade 5B", 5, [70, 20, 6, 4]),  # weakest class (falls under the 75% flag)
]

FIRST_NAMES = [
    "Ava", "Liam", "Noah", "Emma", "Mia", "Lucas", "Zoe", "Ethan", "Chloe", "Mason",
    "Nia", "Kai", "Amara", "Tendai", "Rudo", "Tatenda", "Farai", "Chipo", "Tafara",
    "Neo", "Thabo", "Lerato", "Sipho", "Naledi", "Kuda", "Anesu", "Ruvimbo", "Tino",
]
LAST_NAMES = [
    "Moyo", "Ncube", "Dube", "Sibanda", "Chikwanha", "Mutasa", "Banda", "Phiri",
    "Smith", "Jones", "Khumalo", "Mpofu", "Ndlovu", "Hove", "Chirwa", "Zulu",
    "Nkomo", "Gumbo", "Marufu", "Tshuma", "Mlambo", "Shumba", "Mhlanga", "Cele",
]
TEACHER_FIRST = ["Grace", "Peter", "Joyce", "David", "Ruth", "Samuel"]
TEACHER_LAST = ["Mawere", "Sithole", "Chuma", "Maseko", "Taylor", "Okafor"]


def latest_weekday(day):
    while day.weekday() >= 5:
        day -= timedelta(days=1)
    return day


def school_days_ending(end, count):
    """Return ``count`` weekdays ending on ``end`` (inclusive), oldest first."""
    days, current = [], end
    while len(days) < count:
        if current.weekday() < 5:
            days.append(current)
        current -= timedelta(days=1)
    return list(reversed(days))


class Command(BaseCommand):
    help = "Seed the database with a demo school, classes, students and attendance."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Delete existing data first.")
        parser.add_argument("--seed", type=int, default=42, help="Random seed (default 42).")
        parser.add_argument(
            "--school-days", type=int, default=90, help="School days per term (default 90)."
        )

    @transaction.atomic
    def handle(self, *args, **options):
        if options["reset"]:
            for model in (AttendanceRecord, Student, ClassRoom, Teacher, AcademicTerm, School):
                model.objects.all().delete()
            self.stdout.write("Existing data deleted.")
        elif School.objects.exists():
            self.stdout.write(
                self.style.WARNING("Data already present. Use --reset to wipe and re-seed.")
            )
            return

        rng = random.Random(options["seed"])
        days_per_term = options["school_days"]

        school = School.objects.create(name="Greenfield Primary School", address="12 Jacaranda Ave")
        terms, term_days = self._create_terms(school, days_per_term)

        students = self._create_classes_and_students(school, rng)
        self.stdout.write(f"Created {len(students)} students in {len(CLASSES)} classes.")

        records = []
        for entry in students:
            for index, (term, days) in enumerate(zip(terms, term_days)):
                is_latest = index == len(terms) - 1
                records.extend(self._student_term_records(entry, term, days, is_latest, rng))
        AttendanceRecord.objects.bulk_create(records, batch_size=2000)

        self.stdout.write(
            self.style.SUCCESS(f"Created {len(records)} attendance records across {len(terms)} terms.")
        )

    # ------------------------------------------------------------------
    def _create_terms(self, school, days_per_term):
        """Three consecutive terms; the newest ends on the latest weekday (so 'today' has data)."""
        windows = []
        end = latest_weekday(date.today())
        for _ in range(3):
            days = school_days_ending(end, days_per_term)
            windows.append(days)
            end = latest_weekday(days[0] - timedelta(days=15))
        windows.reverse()  # oldest first

        terms = []
        for number, days in enumerate(windows, start=1):
            terms.append(
                AcademicTerm.objects.create(
                    name=f"Term {number} {days[0].year}",
                    school=school,
                    start_date=days[0],
                    end_date=days[-1],
                )
            )
        return terms, windows

    def _create_classes_and_students(self, school, rng):
        entries, counter = [], 1
        for index, (name, grade, class_weights) in enumerate(CLASSES):
            first, last = TEACHER_FIRST[index], TEACHER_LAST[index]
            teacher = Teacher.objects.create(
                first_name=first, last_name=last, email=f"{first}.{last}@greenfield.example".lower()
            )
            classroom = ClassRoom.objects.create(
                name=name, grade_level=grade, teacher=teacher, school=school
            )
            batch = []
            for _ in range(rng.randint(25, 30)):
                batch.append(
                    Student(
                        first_name=rng.choice(FIRST_NAMES),
                        last_name=rng.choice(LAST_NAMES),
                        admission_number=f"ADM{counter:05d}",
                        classroom=classroom,
                    )
                )
                counter += 1
            Student.objects.bulk_create(batch)
            created = list(Student.objects.filter(classroom=classroom))

            # Pick special cases from the class (distinct students).
            special = rng.sample(created, 4)
            roles = {
                special[0].pk: "at_risk",
                special[1].pk: "dropper",
                special[2].pk: "streaker",
                special[3].pk: "dropper" if index % 2 == 0 else "normal",
            }
            for student in created:
                entries.append(
                    {
                        "student": student,
                        "role": roles.get(student.pk, "normal"),
                        "class_weights": class_weights,
                    }
                )
        return entries

    def _student_term_records(self, entry, term, days, is_latest, rng):
        role = entry["role"]
        weights = entry["class_weights"]
        if role == "at_risk":
            weights = AT_RISK
        elif role == "dropper":
            weights = DROPPED if is_latest else GOOD

        statuses = rng.choices(STATUSES, weights=weights, k=len(days))
        if role == "streaker" and is_latest and len(days) > 20:
            start = rng.randint(5, len(days) - 10)
            for offset in range(rng.randint(4, 6)):
                statuses[start + offset] = S.ABSENT

        records = []
        for day, status in zip(days, statuses):
            note = ""
            if status == S.EXCUSED:
                note = "Excused absence"
            elif status == S.ABSENT and rng.random() < 0.3:
                note = rng.choice(["Illness", "Family matter", "No reason given"])
            records.append(
                AttendanceRecord(
                    student=entry["student"], term=term, date=day, status=status, notes=note
                )
            )
        return records
