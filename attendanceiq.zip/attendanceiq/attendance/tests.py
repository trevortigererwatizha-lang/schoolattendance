import pytest
from django.core.management import call_command
from django.db import IntegrityError, transaction

from attendance.models import AcademicTerm, AttendanceRecord, ClassRoom, School, Student, Teacher


def test_duplicate_student_date_is_rejected(dataset):
    existing = AttendanceRecord.objects.filter(student=dataset.s1).first()
    with pytest.raises(IntegrityError), transaction.atomic():
        AttendanceRecord.objects.create(
            student=dataset.s1, term=existing.term, date=existing.date, status="ABSENT"
        )


def test_str_methods(dataset):
    assert str(dataset.school) == "Test School"
    assert str(dataset.term1) == "Term 1 2024"
    assert str(dataset.class5) == "Grade 5A"
    assert "Ann One" in str(dataset.s1) and "A001" in str(dataset.s1)


def test_seed_data_command(db):
    call_command("seed_data", "--school-days", "10", verbosity=0)
    assert School.objects.count() == 1
    assert AcademicTerm.objects.count() == 3
    assert ClassRoom.objects.count() == 6
    assert Teacher.objects.count() == 6
    students = Student.objects.count()
    assert 150 <= students <= 180
    assert AttendanceRecord.objects.count() == students * 30

    # Running again without --reset must not duplicate anything.
    call_command("seed_data", "--school-days", "10", verbosity=0)
    assert Student.objects.count() == students
