from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import F, Q


class School(models.Model):
    name = models.CharField(max_length=255)
    address = models.TextField(blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class AcademicTerm(models.Model):
    name = models.CharField(max_length=100, help_text='e.g. "Term 1 2024"')
    start_date = models.DateField()
    end_date = models.DateField()
    school = models.ForeignKey(School, on_delete=models.CASCADE, related_name="terms")

    class Meta:
        ordering = ["-start_date"]
        constraints = [
            models.CheckConstraint(
                condition=Q(end_date__gt=F("start_date")),
                name="term_end_after_start",
            ),
        ]

    def __str__(self):
        return self.name


class Teacher(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)

    class Meta:
        ordering = ["last_name", "first_name"]

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    def __str__(self):
        return self.full_name


class ClassRoom(models.Model):
    name = models.CharField(max_length=100, help_text='e.g. "Grade 5A"')
    grade_level = models.PositiveSmallIntegerField()
    teacher = models.ForeignKey(
        Teacher, on_delete=models.SET_NULL, null=True, blank=True, related_name="classrooms"
    )
    school = models.ForeignKey(School, on_delete=models.CASCADE, related_name="classrooms")

    class Meta:
        ordering = ["grade_level", "name"]
        constraints = [
            models.UniqueConstraint(fields=["school", "name"], name="unique_class_name_per_school"),
        ]

    def __str__(self):
        return self.name


class Student(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    admission_number = models.CharField(max_length=30, unique=True)
    classroom = models.ForeignKey(ClassRoom, on_delete=models.CASCADE, related_name="students")

    class Meta:
        ordering = ["last_name", "first_name"]
        indexes = [models.Index(fields=["last_name", "first_name"], name="student_name_idx")]

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    def __str__(self):
        return f"{self.full_name} ({self.admission_number})"


class AttendanceRecord(models.Model):
    class Status(models.TextChoices):
        PRESENT = "PRESENT", "Present"
        ABSENT = "ABSENT", "Absent"
        LATE = "LATE", "Late"
        EXCUSED = "EXCUSED", "Excused"

    student = models.ForeignKey(
        Student, on_delete=models.CASCADE, related_name="attendance_records"
    )
    date = models.DateField()
    status = models.CharField(max_length=10, choices=Status.choices)
    term = models.ForeignKey(AcademicTerm, on_delete=models.CASCADE, related_name="records")
    notes = models.CharField(max_length=255, blank=True)

    # NOTE: deliberately no Meta.ordering. Default ordering would be added to the
    # GROUP BY of every .values().annotate() aggregation in the analytics layer.
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["student", "date"], name="unique_student_date"),
        ]
        indexes = [
            models.Index(fields=["date"], name="att_date_idx"),
            models.Index(fields=["status"], name="att_status_idx"),
            models.Index(fields=["student", "date"], name="att_student_date_idx"),
            models.Index(fields=["term", "date"], name="att_term_date_idx"),
        ]

    def clean(self):
        if self.term_id and self.date and not (
            self.term.start_date <= self.date <= self.term.end_date
        ):
            raise ValidationError("Date falls outside the selected term.")

    def __str__(self):
        return f"{self.student_id} {self.date} {self.status}"
