from django.core.paginator import Paginator
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404, render

from analytics.services import analytics as svc
from core.utils import get_int

from .models import ClassRoom, Student


def student_list(request):
    query = request.GET.get("q", "").strip()
    classroom_id = get_int(request, "classroom")

    students = (
        Student.objects.select_related("classroom")
        .annotate(
            total=Count("attendance_records"),
            attended=Count(
                "attendance_records",
                filter=Q(attendance_records__status__in=svc.ATTENDED_STATUSES),
            ),
        )
        .order_by("classroom__name", "last_name", "first_name")
    )
    if query:
        students = students.filter(
            Q(first_name__icontains=query)
            | Q(last_name__icontains=query)
            | Q(admission_number__icontains=query)
        )
    if classroom_id:
        students = students.filter(classroom_id=classroom_id)

    page = Paginator(students, 25).get_page(request.GET.get("page"))
    rows = list(page.object_list)
    for student in rows:
        student.rate = round(student.attended * 100 / student.total, 1) if student.total else None

    return render(
        request,
        "attendance/student_list.html",
        {
            "page": page,
            "rows": rows,
            "q": query,
            "classroom_id": classroom_id,
            "classrooms": ClassRoom.objects.all(),
        },
    )


def student_detail(request, pk):
    student = get_object_or_404(Student.objects.select_related("classroom__teacher"), pk=pk)
    records = student.attendance_records
    pairs = list(records.order_by("date").values_list("date", "status"))
    monthly = svc.get_student_monthly_breakdown(student)

    return render(
        request,
        "attendance/student_detail.html",
        {
            "student": student,
            "summary": svc.get_student_summary(student),
            "monthly": monthly,
            "months": svc.build_calendar_months(pairs),
            "recent": records.select_related("term").order_by("-date")[:15],
            "monthly_chart": {
                "labels": [m["month"].strftime("%b %Y") for m in monthly],
                "values": [m["rate"] for m in monthly],
            },
        },
    )
