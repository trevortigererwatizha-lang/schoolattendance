from django.contrib import admin

from .models import AcademicTerm, AttendanceRecord, ClassRoom, School, Student, Teacher


@admin.register(School)
class SchoolAdmin(admin.ModelAdmin):
    list_display = ("name", "address")
    search_fields = ("name", "address")


@admin.register(AcademicTerm)
class AcademicTermAdmin(admin.ModelAdmin):
    list_display = ("name", "school", "start_date", "end_date")
    list_filter = ("school",)
    search_fields = ("name",)
    list_select_related = ("school",)


@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ("last_name", "first_name", "email")
    search_fields = ("first_name", "last_name", "email")


@admin.register(ClassRoom)
class ClassRoomAdmin(admin.ModelAdmin):
    list_display = ("name", "grade_level", "teacher", "school")
    list_filter = ("school", "grade_level")
    search_fields = ("name", "teacher__last_name")
    list_select_related = ("teacher", "school")


class AttendanceRecordInline(admin.TabularInline):
    model = AttendanceRecord
    extra = 0
    fields = ("date", "status", "term", "notes")
    ordering = ("-date",)


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ("admission_number", "last_name", "first_name", "classroom")
    list_filter = ("classroom__grade_level", "classroom")
    search_fields = ("first_name", "last_name", "admission_number")
    list_select_related = ("classroom",)
    inlines = [AttendanceRecordInline]


@admin.register(AttendanceRecord)
class AttendanceRecordAdmin(admin.ModelAdmin):
    list_display = ("date", "student", "status", "term")
    list_filter = ("status", "term", "student__classroom")
    search_fields = ("student__first_name", "student__last_name", "student__admission_number")
    list_select_related = ("student", "term")
    date_hierarchy = "date"
    raw_id_fields = ("student",)
