"""Shared fixtures: a tiny hand-computable dataset.

Two terms (5 school days each), two classes, three students.

Term 1 (Jan 8-12 2024)           Term 2 (Apr 8-12 2024)
  s1 (5A): P P P P P  -> 100%      s1 (5A): P P P P P  -> 100%
  s2 (5A): P P L A P  ->  80%      s2 (5A): A A A A A  ->   0%
  s3 (6A): P P P P P  -> 100%      s3 (6A): P E P A P  ->  60%
"""
from datetime import date
from types import SimpleNamespace

import pytest

from attendance.models import (
    AcademicTerm,
    AttendanceRecord,
    ClassRoom,
    School,
    Student,
    Teacher,
)

P, A, L, E = "PRESENT", "ABSENT", "LATE", "EXCUSED"
TERM1_DAYS = [date(2024, 1, day) for day in range(8, 13)]
TERM2_DAYS = [date(2024, 4, day) for day in range(8, 13)]


@pytest.fixture
def dataset(db):
    school = School.objects.create(name="Test School", address="1 Main St")
    term1 = AcademicTerm.objects.create(
        name="Term 1 2024", school=school, start_date=date(2024, 1, 1), end_date=date(2024, 3, 31)
    )
    term2 = AcademicTerm.objects.create(
        name="Term 2 2024", school=school, start_date=date(2024, 4, 1), end_date=date(2024, 6, 30)
    )
    teacher_a = Teacher.objects.create(first_name="Tina", last_name="Teach", email="tina@example.com")
    teacher_b = Teacher.objects.create(first_name="Tom", last_name="Tutor", email="tom@example.com")
    class5 = ClassRoom.objects.create(name="Grade 5A", grade_level=5, teacher=teacher_a, school=school)
    class6 = ClassRoom.objects.create(name="Grade 6A", grade_level=6, teacher=teacher_b, school=school)
    s1 = Student.objects.create(first_name="Ann", last_name="One", admission_number="A001", classroom=class5)
    s2 = Student.objects.create(first_name="Ben", last_name="Two", admission_number="A002", classroom=class5)
    s3 = Student.objects.create(first_name="Cy", last_name="Three", admission_number="A003", classroom=class6)

    def add(student, term, days, statuses):
        AttendanceRecord.objects.bulk_create(
            AttendanceRecord(student=student, term=term, date=day, status=status)
            for day, status in zip(days, statuses)
        )

    add(s1, term1, TERM1_DAYS, [P, P, P, P, P])
    add(s2, term1, TERM1_DAYS, [P, P, L, A, P])
    add(s3, term1, TERM1_DAYS, [P, P, P, P, P])
    add(s1, term2, TERM2_DAYS, [P, P, P, P, P])
    add(s2, term2, TERM2_DAYS, [A, A, A, A, A])
    add(s3, term2, TERM2_DAYS, [P, E, P, A, P])

    return SimpleNamespace(
        school=school, term1=term1, term2=term2, class5=class5, class6=class6, s1=s1, s2=s2, s3=s3
    )
