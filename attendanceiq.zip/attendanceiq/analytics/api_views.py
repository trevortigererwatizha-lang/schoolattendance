"""Plain JSON endpoints (no DRF dependency)."""
from django.http import JsonResponse
from django.views.decorators.http import require_GET

from attendance.models import AcademicTerm, ClassRoom

from .params import resolve_classroom, resolve_term
from .services import analytics as svc


@require_GET
def daily_attendance(request):
    """GET /api/attendance/daily/?term=<id>&classroom=<id>"""
    term = resolve_term(request)
    classroom = resolve_classroom(request)
    if term is None:
        return JsonResponse({"term": None, "classroom": None, "data": []})
    trend = svc.get_daily_attendance_trend(classroom, term)
    return JsonResponse(
        {
            "term": term.pk,
            "classroom": classroom.pk if classroom else None,
            "data": [{"date": row["date"].isoformat(), "rate": row["rate"]} for row in trend],
        }
    )


@require_GET
def class_comparison(request):
    """GET /api/analytics/class-comparison/?term=<id>"""
    term = resolve_term(request)
    if term is None:
        return JsonResponse({"term": None, "data": []})
    return JsonResponse({"term": term.pk, "data": svc.get_class_comparison(term)})


@require_GET
def term_trends(request):
    """GET /api/analytics/term-trends/?classes=<id,id>  (omit for all classes)"""
    ids = [int(part) for part in request.GET.get("classes", "").split(",") if part.strip().isdigit()]
    class_names = None
    if ids:
        class_names = list(ClassRoom.objects.filter(pk__in=ids).values_list("name", flat=True))
    terms = AcademicTerm.objects.order_by("start_date")
    return JsonResponse(svc.get_termly_trend_by_class(class_names, terms))
