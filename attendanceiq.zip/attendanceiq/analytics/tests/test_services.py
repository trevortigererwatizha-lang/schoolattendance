from datetime import date

from attendance.models import AcademicTerm, AttendanceRecord
from analytics.services import analytics as svc


# --- rates ---------------------------------------------------------------
def test_rate_of_empty_queryset_is_zero(db):
    assert svc.get_attendance_rate(AttendanceRecord.objects.none()) == 0.0


def test_rate_counts_present_and_late_as_attended(dataset):
    # 22 attended of 30 records
    assert svc.get_attendance_rate(AttendanceRecord.objects.all()) == 73.3


def test_rate_per_term(dataset):
    assert svc.get_attendance_rate(AttendanceRecord.objects.filter(term=dataset.term1)) == 93.3
    assert svc.get_attendance_rate(AttendanceRecord.objects.filter(term=dataset.term2)) == 53.3


def test_status_counts_for_a_day(dataset):
    day = AttendanceRecord.objects.filter(date=date(2024, 4, 9))
    counts = svc.get_status_counts(day)
    assert counts == {"total": 3, "present": 1, "absent": 1, "late": 0, "excused": 1}


# --- daily trend ---------------------------------------------------------
def test_daily_trend_for_term(dataset):
    trend = svc.get_daily_attendance_trend(term=dataset.term1)
    assert [row["date"] for row in trend] == [date(2024, 1, d) for d in range(8, 13)]
    assert [row["rate"] for row in trend] == [100.0, 100.0, 100.0, 66.7, 100.0]


def test_daily_trend_filters_by_classroom(dataset):
    trend = svc.get_daily_attendance_trend(classroom=dataset.class6, term=dataset.term2)
    assert [row["rate"] for row in trend] == [100.0, 0.0, 100.0, 0.0, 100.0]


# --- class comparison ----------------------------------------------------
def test_class_comparison_term1(dataset):
    rows = svc.get_class_comparison(dataset.term1)
    assert [r["class_name"] for r in rows] == ["Grade 5A", "Grade 6A"]
    assert rows[0] == {
        "classroom_id": dataset.class5.pk, "class_name": "Grade 5A",
        "students": 2, "rate": 90.0, "absences": 1, "late_count": 1,
    }
    assert rows[1]["rate"] == 100.0 and rows[1]["students"] == 1


def test_class_comparison_term2(dataset):
    rows = {r["class_name"]: r for r in svc.get_class_comparison(dataset.term2)}
    assert rows["Grade 5A"]["rate"] == 50.0 and rows["Grade 5A"]["absences"] == 5
    assert rows["Grade 6A"]["rate"] == 60.0 and rows["Grade 6A"]["absences"] == 1


def test_low_attendance_classes_respects_threshold(dataset):
    both = svc.get_low_attendance_classes(dataset.term2, threshold=75)
    only_5a = svc.get_low_attendance_classes(dataset.term2, threshold=55)
    assert {r["class_name"] for r in both} == {"Grade 5A", "Grade 6A"}
    assert [r["class_name"] for r in only_5a] == ["Grade 5A"]


# --- term trends ---------------------------------------------------------
def test_termly_trend_by_class(dataset):
    terms = AcademicTerm.objects.all()  # default ordering is newest first; service must re-sort
    result = svc.get_termly_trend_by_class(["Grade 5A", "Grade 6A"], terms)
    assert result["labels"] == ["Term 1 2024", "Term 2 2024"]
    assert result["series"] == [
        {"class_name": "Grade 5A", "rates": [90.0, 50.0]},
        {"class_name": "Grade 6A", "rates": [100.0, 60.0]},
    ]


def test_termly_trend_none_means_all_classes_and_missing_is_none(dataset):
    only_term1 = AcademicTerm.objects.filter(pk=dataset.term1.pk)
    result = svc.get_termly_trend_by_class(None, only_term1)
    assert [s["class_name"] for s in result["series"]] == ["Grade 5A", "Grade 6A"]
    result = svc.get_termly_trend_by_class(["Grade 5A", "Nonexistent"], AcademicTerm.objects.all())
    assert result["series"][1] == {"class_name": "Nonexistent", "rates": [None, None]}


# --- streak helpers ------------------------------------------------------
def test_longest_and_current_absence_streak():
    statuses = ["PRESENT", "ABSENT", "ABSENT", "LATE", "ABSENT"]
    assert svc.longest_absence_streak(statuses) == 2
    assert svc.current_absence_streak(statuses) == 1
    assert svc.longest_absence_streak([]) == 0
    assert svc.current_absence_streak(["ABSENT"] * 3) == 3


# --- flags ---------------------------------------------------------------
def test_at_risk_students_in_term(dataset):
    result = svc.get_at_risk_students(threshold=0.75, consecutive_days=3, term=dataset.term2)
    by_id = {r["student"].pk: r for r in result}
    assert set(by_id) == {dataset.s2.pk, dataset.s3.pk}
    assert by_id[dataset.s2.pk]["longest_streak"] == 5
    assert by_id[dataset.s2.pk]["rate"] == 0.0
    assert by_id[dataset.s3.pk]["rate"] == 60.0
    assert result[0]["student"].pk == dataset.s2.pk  # worst first


def test_at_risk_students_across_all_terms(dataset):
    result = svc.get_at_risk_students()
    assert [r["student"].pk for r in result] == [dataset.s2.pk]  # s3 is at 80% overall


def test_consecutive_days_threshold_is_strictly_greater_than(dataset):
    # s2 has a 5-day run: flagged when limit is 4, not flagged when limit is 5 (rate alone is fine).
    flagged = svc.get_at_risk_students(threshold=0.0, consecutive_days=4, term=dataset.term2)
    assert [r["student"].pk for r in flagged] == [dataset.s2.pk]
    assert svc.get_at_risk_students(threshold=0.0, consecutive_days=5, term=dataset.term2) == []


def test_attendance_drops(dataset):
    drops = svc.get_attendance_drops(dataset.term2, min_drop=20)
    assert [(d["student"].pk, d["drop"]) for d in drops] == [
        (dataset.s2.pk, 80.0),
        (dataset.s3.pk, 40.0),
    ]
    assert [d["student"].pk for d in svc.get_attendance_drops(dataset.term2, min_drop=50)] == [dataset.s2.pk]


def test_attendance_drops_without_previous_term(dataset):
    assert svc.get_attendance_drops(dataset.term1) == []


# --- terms ---------------------------------------------------------------
def test_current_and_previous_term(dataset):
    assert svc.get_current_term(today=date(2024, 4, 10)) == dataset.term2
    assert svc.get_current_term(today=date(2024, 2, 1)) == dataset.term1
    assert svc.get_current_term(today=date(2030, 1, 1)) == dataset.term2  # falls back to latest
    assert svc.get_previous_term(dataset.term2) == dataset.term1
    assert svc.get_previous_term(dataset.term1) is None


# --- single student ------------------------------------------------------
def test_student_summary(dataset):
    summary = svc.get_student_summary(dataset.s2)
    assert summary["total"] == 10
    assert (summary["present"], summary["late"], summary["absent"], summary["excused"]) == (3, 1, 6, 0)
    assert summary["rate"] == 40.0
    assert summary["current_streak"] == 5
    assert summary["longest_streak"] == 5


def test_student_monthly_breakdown(dataset):
    months = svc.get_student_monthly_breakdown(dataset.s3)
    assert [m["month"] for m in months] == [date(2024, 1, 1), date(2024, 4, 1)]
    assert [m["rate"] for m in months] == [100.0, 60.0]


def test_build_calendar_months():
    months = svc.build_calendar_months([(date(2024, 1, 8), "PRESENT"), (date(2024, 2, 5), "ABSENT")])
    assert [m["label"] for m in months] == ["January 2024", "February 2024"]
    assert months[0]["blank_cells"] == []          # 1 Jan 2024 is a Monday
    assert len(months[1]["blank_cells"]) == 3      # 1 Feb 2024 is a Thursday
    assert len(months[0]["days"]) == 31
    assert months[0]["days"][7]["status"] == "PRESENT"
    assert months[0]["days"][0]["status"] is None
