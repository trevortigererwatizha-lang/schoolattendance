import pytest
from django.urls import reverse


def test_dashboard_renders_with_latest_term(client, dataset):
    response = client.get(reverse("analytics:dashboard"))
    assert response.status_code == 200
    assert response.context["term"] == dataset.term2
    assert response.context["overall_rate"] == 53.3
    assert response.context["total_students"] == 3
    assert response.context["total_classes"] == 2
    assert response.context["counts"]["total"] == 3
    assert b"trendChart" in response.content


def test_dashboard_filters_by_term_and_class(client, dataset):
    url = reverse("analytics:dashboard")
    by_term = client.get(url, {"term": dataset.term1.pk})
    assert by_term.context["overall_rate"] == 93.3
    by_class = client.get(url, {"term": dataset.term2.pk, "classroom": dataset.class6.pk})
    assert by_class.context["overall_rate"] == 60.0
    assert by_class.context["total_students"] == 1
    assert [v for v in by_class.context["trend_data"]["values"]] == [100.0, 0.0, 100.0, 0.0, 100.0]


def test_pages_render_on_empty_database(client, db):
    for name in ("analytics:dashboard", "analytics:classes", "analytics:terms",
                 "analytics:insights", "attendance:student_list"):
        assert client.get(reverse(name)).status_code == 200


def test_class_comparison_highlights_below_threshold(client, dataset):
    url = reverse("analytics:classes")
    default = client.get(url, {"term": dataset.term2.pk})  # default threshold 80 -> both below
    assert [r["below"] for r in default.context["rows"]] == [True, True]
    custom = client.get(url, {"term": dataset.term2.pk, "threshold": "55"})
    assert [r["below"] for r in custom.context["rows"]] == [True, False]


def test_term_trends_filters(client, dataset):
    url = reverse("analytics:terms")
    everything = client.get(url)
    assert everything.status_code == 200
    assert len(everything.context["trend"]["series"]) == 2
    grade_six = client.get(url, {"grade": 6})
    assert [s["class_name"] for s in grade_six.context["trend"]["series"]] == ["Grade 6A"]
    chosen = client.get(url, {"classes": [dataset.class5.pk]})
    assert [s["class_name"] for s in chosen.context["trend"]["series"]] == ["Grade 5A"]


def test_insights_lists_flags(client, dataset):
    response = client.get(reverse("analytics:insights"))
    assert response.status_code == 200
    assert {r["student"].pk for r in response.context["at_risk"]} == {dataset.s2.pk, dataset.s3.pk}
    assert {d["student"].pk for d in response.context["drops"]} == {dataset.s2.pk, dataset.s3.pk}
    assert {c["class_name"] for c in response.context["low_classes"]} == {"Grade 5A", "Grade 6A"}
    link = reverse("attendance:student_detail", args=[dataset.s2.pk])
    assert link.encode() in response.content


def test_student_detail(client, dataset):
    response = client.get(reverse("attendance:student_detail", args=[dataset.s2.pk]))
    assert response.status_code == 200
    assert response.context["summary"]["rate"] == 40.0
    assert response.context["summary"]["current_streak"] == 5
    assert len(response.context["months"]) == 2


def test_student_detail_404(client, dataset):
    assert client.get(reverse("attendance:student_detail", args=[9999])).status_code == 404


def test_student_list_search(client, dataset):
    url = reverse("attendance:student_list")
    response = client.get(url, {"q": "Ben"})
    assert [s.pk for s in response.context["rows"]] == [dataset.s2.pk]
    assert response.context["rows"][0].rate == 40.0


def test_views_avoid_n_plus_one(client, dataset, django_assert_max_num_queries):
    with django_assert_max_num_queries(20):
        client.get(reverse("analytics:insights"))
    with django_assert_max_num_queries(12):
        client.get(reverse("analytics:classes"))
    with django_assert_max_num_queries(12):
        client.get(reverse("attendance:student_list"))


def test_login_required_when_enabled(client, dataset, settings):
    settings.REQUIRE_LOGIN = True
    response = client.get(reverse("analytics:dashboard"))
    assert response.status_code == 302
    assert response["Location"].startswith("/admin/login/")


# --- API -----------------------------------------------------------------
def test_api_daily(client, dataset):
    response = client.get(reverse("api:daily"), {"term": dataset.term2.pk})
    body = response.json()
    assert response.status_code == 200
    assert body["term"] == dataset.term2.pk
    assert len(body["data"]) == 5
    assert body["data"][0] == {"date": "2024-04-08", "rate": 66.7}


def test_api_class_comparison(client, dataset):
    body = client.get(reverse("api:class_comparison"), {"term": dataset.term1.pk}).json()
    assert [row["class_name"] for row in body["data"]] == ["Grade 5A", "Grade 6A"]
    assert body["data"][0]["rate"] == 90.0


def test_api_term_trends(client, dataset):
    body = client.get(reverse("api:term_trends"), {"classes": f"{dataset.class6.pk}"}).json()
    assert body["labels"] == ["Term 1 2024", "Term 2 2024"]
    assert body["series"] == [{"class_name": "Grade 6A", "rates": [100.0, 60.0]}]


def test_api_rejects_post(client, dataset):
    assert client.post(reverse("api:daily")).status_code == 405
