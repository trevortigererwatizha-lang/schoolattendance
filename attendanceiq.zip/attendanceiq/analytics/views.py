from django.conf import settings
from django.db.models import Max
from django.shortcuts import render
from django.utils import timezone

from attendance.models import AcademicTerm, AttendanceRecord, ClassRoom, Student
from core.utils import get_float, get_int

from .params import resolve_classroom, resolve_term
from .services import analytics as svc


def dashboard(request):
    term = resolve_term(request)
    classroom = resolve_classroom(request)

    records = AttendanceRecord.objects.filter(term=term) if term else AttendanceRecord.objects.none()
    students = Student.objects.all()
    if classroom:
        records = records.filter(student__classroom=classroom)
        students = students.filter(classroom=classroom)

    # "Today" card: today if there is data for it, otherwise the latest recorded day.
    card_date = None
    if term:
        today = timezone.localdate()
        if records.filter(date=today).exists():
            card_date = today
        else:
            card_date = records.aggregate(latest=Max("date"))["latest"]
    day_records = records.filter(date=card_date) if card_date else records.none()

    trend = svc.get_daily_attendance_trend(classroom, term) if term else []

    return render(
        request,
        "analytics/dashboard.html",
        {
            "term": term,
            "classroom": classroom,
            "terms": AcademicTerm.objects.order_by("-start_date"),
            "classrooms": ClassRoom.objects.all(),
            "total_students": students.count(),
            "total_classes": 1 if classroom else ClassRoom.objects.count(),
            "overall_rate": svc.get_attendance_rate(records),
            "card_date": card_date,
            "counts": svc.get_status_counts(day_records),
            "trend": trend,
            "trend_data": {
                "labels": [row["date"].isoformat() for row in trend],
                "values": [row["rate"] for row in trend],
            },
        },
    )


def class_comparison(request):
    term = resolve_term(request)
    threshold = get_float(request, "threshold", settings.ATTENDANCE_CLASS_THRESHOLD)
    rows = svc.get_class_comparison(term) if term else []
    for row in rows:
        row["below"] = row["rate"] < threshold

    return render(
        request,
        "analytics/class_comparison.html",
        {
            "term": term,
            "terms": AcademicTerm.objects.order_by("-start_date"),
            "threshold": threshold,
            "rows": rows,
            "chart_data": {
                "labels": [row["class_name"] for row in rows],
                "values": [row["rate"] for row in rows],
                "below": [row["below"] for row in rows],
                "threshold": threshold,
            },
        },
    )


def term_trends(request):
    terms = list(AcademicTerm.objects.order_by("start_date"))
    classrooms = ClassRoom.objects.all()

    grade = get_int(request, "grade")
    selected_ids = [int(value) for value in request.GET.getlist("classes") if value.isdigit()]

    filtered = classrooms
    if grade is not None:
        filtered = filtered.filter(grade_level=grade)
    if selected_ids:
        filtered = filtered.filter(pk__in=selected_ids)
    class_names = list(filtered.values_list("name", flat=True))

    trend = svc.get_termly_trend_by_class(class_names, terms)
    return render(
        request,
        "analytics/term_trends.html",
        {
            "trend": trend,
            "classrooms": classrooms,
            "grades": classrooms.values_list("grade_level", flat=True).order_by("grade_level").distinct(),
            "grade": grade,
            "selected_ids": selected_ids,
        },
    )


def insights(request):
    term = resolve_term(request)
    at_risk, drops, low_classes = [], [], []
    if term:
        at_risk = svc.get_at_risk_students(
            threshold=0.75,
            consecutive_days=settings.INSIGHT_CONSECUTIVE_ABSENCES,
            term=term,
        )
        drops = svc.get_attendance_drops(term, min_drop=settings.INSIGHT_DROP_POINTS)
        low_classes = svc.get_low_attendance_classes(term, threshold=settings.INSIGHT_LOW_CLASS_RATE)

    return render(
        request,
        "analytics/insights.html",
        {
            "term": term,
            "terms": AcademicTerm.objects.order_by("-start_date"),
            "at_risk": at_risk,
            "drops": drops,
            "low_classes": low_classes,
            "consecutive_limit": settings.INSIGHT_CONSECUTIVE_ABSENCES,
            "low_class_rate": settings.INSIGHT_LOW_CLASS_RATE,
            "drop_points": settings.INSIGHT_DROP_POINTS,
        },
    )
