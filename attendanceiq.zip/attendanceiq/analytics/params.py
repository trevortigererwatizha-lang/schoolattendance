"""Resolve term/classroom filters from query-string parameters."""
from attendance.models import AcademicTerm, ClassRoom
from core.utils import get_int

from .services.analytics import get_current_term


def resolve_term(request, key="term"):
    """Selected term, falling back to the current (or latest) term."""
    term_id = get_int(request, key)
    if term_id is not None:
        term = AcademicTerm.objects.filter(pk=term_id).first()
        if term is not None:
            return term
    return get_current_term()


def resolve_classroom(request, key="classroom"):
    """Selected classroom, or None for 'all classes'."""
    classroom_id = get_int(request, key)
    if classroom_id is None:
        return None
    return ClassRoom.objects.filter(pk=classroom_id).first()
