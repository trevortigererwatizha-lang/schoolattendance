"""Analytics service layer.

Pure query/aggregation functions with no request or template logic, so they can be
unit-tested directly. Aggregation happens in the database (``Count`` with ``filter=``);
Python only ever sees one row per group (per day, per class, per student), never one
row per attendance record, with a single bounded exception documented in
``get_at_risk_students``.

Attendance rate definition
--------------------------
``rate = (PRESENT + LATE) / all records * 100``. Late students did attend; absent and
excused students did not. Rates are percentages rounded to one decimal place.
"""
import calendar
from collections import defaultdict
from datetime import date
from itertools import groupby
from operator import itemgetter

from django.db.models import Count, Q
from django.db.models.functions import TruncMonth
from django.utils import timezone

from attendance.models import AcademicTerm, AttendanceRecord, Student

Status = AttendanceRecord.Status
ATTENDED_STATUSES = (Status.PRESENT, Status.LATE)


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def _rate(attended, total):
    return round(attended * 100 / total, 1) if total else 0.0


def _attended_count():
    return Count("id", filter=Q(status__in=ATTENDED_STATUSES))


def _status_count(status):
    return Count("id", filter=Q(status=status))


def longest_absence_streak(statuses):
    """Longest run of consecutive ABSENT entries in an ordered iterable of statuses."""
    longest = current = 0
    for status in statuses:
        if status == Status.ABSENT:
            current += 1
            longest = max(longest, current)
        else:
            current = 0
    return longest


def current_absence_streak(statuses):
    """Number of ABSENT entries at the very end of an ordered list of statuses."""
    streak = 0
    for status in reversed(list(statuses)):
        if status != Status.ABSENT:
            break
        streak += 1
    return streak


# --------------------------------------------------------------------------
# Terms
# --------------------------------------------------------------------------
def get_current_term(school=None, today=None):
    """Term containing ``today``; otherwise the most recent term by start date."""
    today = today or timezone.localdate()
    terms = AcademicTerm.objects.all()
    if school is not None:
        terms = terms.filter(school=school)
    current = terms.filter(start_date__lte=today, end_date__gte=today).order_by("-start_date").first()
    return current or terms.order_by("-start_date").first()


def get_previous_term(term):
    """The term (same school) that started before ``term``, or None."""
    return (
        AcademicTerm.objects.filter(school=term.school, start_date__lt=term.start_date)
        .order_by("-start_date")
        .first()
    )


# --------------------------------------------------------------------------
# Rates and trends
# --------------------------------------------------------------------------
def get_attendance_rate(queryset):
    """Attendance percentage for a queryset of AttendanceRecord (0.0 when empty)."""
    agg = queryset.aggregate(total=Count("id"), attended=_attended_count())
    return _rate(agg["attended"], agg["total"])


def get_status_counts(queryset):
    """Counts per status for a queryset of AttendanceRecord."""
    return queryset.aggregate(
        total=Count("id"),
        present=_status_count(Status.PRESENT),
        absent=_status_count(Status.ABSENT),
        late=_status_count(Status.LATE),
        excused=_status_count(Status.EXCUSED),
    )


def get_daily_attendance_trend(classroom=None, term=None):
    """``[{date, rate}]`` per school day, optionally limited to a class and/or term."""
    records = AttendanceRecord.objects.all()
    if classroom is not None:
        records = records.filter(student__classroom=classroom)
    if term is not None:
        records = records.filter(term=term)
    rows = (
        records.values("date")
        .annotate(total=Count("id"), attended=_attended_count())
        .order_by("date")
    )
    return [{"date": row["date"], "rate": _rate(row["attended"], row["total"])} for row in rows]


def get_class_comparison(term):
    """``[{classroom_id, class_name, students, rate, absences, late_count}]`` for a term."""
    rows = (
        AttendanceRecord.objects.filter(term=term)
        .values("student__classroom_id", "student__classroom__name")
        .annotate(
            students=Count("student", distinct=True),
            total=Count("id"),
            attended=_attended_count(),
            absences=_status_count(Status.ABSENT),
            late_count=_status_count(Status.LATE),
        )
        .order_by("student__classroom__name")
    )
    return [
        {
            "classroom_id": row["student__classroom_id"],
            "class_name": row["student__classroom__name"],
            "students": row["students"],
            "rate": _rate(row["attended"], row["total"]),
            "absences": row["absences"],
            "late_count": row["late_count"],
        }
        for row in rows
    ]


def get_low_attendance_classes(term, threshold=75.0):
    """Classes whose attendance rate for ``term`` is below ``threshold`` percent."""
    return [row for row in get_class_comparison(term) if row["rate"] < threshold]


def get_termly_trend_by_class(class_names, terms):
    """Attendance rate per class per term, shaped for a multi-line chart.

    Returns ``{"labels": [term names], "term_ids": [...], "series": [{"class_name",
    "rates": [rate or None per term]}]}``. ``class_names=None`` means all classes.
    """
    terms = sorted(terms, key=lambda t: t.start_date)
    records = AttendanceRecord.objects.filter(term__in=[t.pk for t in terms])
    if class_names is not None:
        records = records.filter(student__classroom__name__in=list(class_names))

    rows = (
        records.values("student__classroom__name", "term_id")
        .annotate(total=Count("id"), attended=_attended_count())
        .order_by()
    )
    lookup = {
        (row["student__classroom__name"], row["term_id"]): _rate(row["attended"], row["total"])
        for row in rows
    }
    names = sorted(set(class_names)) if class_names is not None else sorted({n for n, _ in lookup})
    return {
        "labels": [t.name for t in terms],
        "term_ids": [t.pk for t in terms],
        "series": [
            {"class_name": name, "rates": [lookup.get((name, t.pk)) for t in terms]}
            for name in names
        ],
    }


# --------------------------------------------------------------------------
# Student flags
# --------------------------------------------------------------------------
def get_at_risk_students(threshold=0.75, consecutive_days=3, term=None):
    """Students with a low attendance rate or a long run of consecutive absences.

    A student is flagged when their rate is below ``threshold`` (a fraction, 0.75 = 75%)
    or they have MORE than ``consecutive_days`` consecutive absent records.

    Rates are computed in SQL (one row per student). Streaks need row order, so for the
    small candidate set only (students with enough absences or a low rate) we stream
    ``(student, status)`` pairs in date order and scan them in Python.

    Returns a list of ``{student, rate, longest_streak, reasons}``, worst first.
    """
    records = AttendanceRecord.objects.all()
    if term is not None:
        records = records.filter(term=term)

    per_student = (
        records.values("student_id")
        .annotate(total=Count("id"), attended=_attended_count(), absent=_status_count(Status.ABSENT))
        .order_by()
    )
    rates, candidates = {}, set()
    for row in per_student:
        rate = row["attended"] / row["total"]
        rates[row["student_id"]] = rate
        if rate < threshold or row["absent"] > consecutive_days:
            candidates.add(row["student_id"])
    if not candidates:
        return []

    streaks = {}
    ordered = (
        records.filter(student_id__in=list(candidates))
        .order_by("student_id", "date")
        .values_list("student_id", "status")
    )
    for student_id, group in groupby(ordered, key=itemgetter(0)):
        streaks[student_id] = longest_absence_streak(status for _, status in group)

    flagged = [
        sid for sid in candidates
        if rates[sid] < threshold or streaks.get(sid, 0) > consecutive_days
    ]
    students = Student.objects.select_related("classroom").in_bulk(flagged)

    results = []
    for sid in flagged:
        reasons = []
        if rates[sid] < threshold:
            reasons.append(f"Attendance {rates[sid] * 100:.1f}% is below {threshold * 100:g}%")
        if streaks.get(sid, 0) > consecutive_days:
            reasons.append(f"{streaks[sid]} consecutive absences")
        results.append(
            {
                "student": students[sid],
                "rate": round(rates[sid] * 100, 1),
                "longest_streak": streaks.get(sid, 0),
                "reasons": reasons,
            }
        )
    results.sort(key=lambda r: (-r["longest_streak"], r["rate"]))
    return results


def get_attendance_drops(term, min_drop=20.0):
    """Students whose rate fell by more than ``min_drop`` percentage points vs the previous term."""
    previous = get_previous_term(term)
    if previous is None:
        return []

    rows = (
        AttendanceRecord.objects.filter(term__in=[term, previous])
        .values("student_id", "term_id")
        .annotate(total=Count("id"), attended=_attended_count())
        .order_by()
    )
    rates = defaultdict(dict)
    for row in rows:
        rates[row["student_id"]][row["term_id"]] = _rate(row["attended"], row["total"])

    dropped = {
        sid: (by_term[previous.pk], by_term[term.pk])
        for sid, by_term in rates.items()
        if previous.pk in by_term and term.pk in by_term
        and by_term[previous.pk] - by_term[term.pk] > min_drop
    }
    students = Student.objects.select_related("classroom").in_bulk(list(dropped))
    results = [
        {
            "student": students[sid],
            "previous_rate": before,
            "current_rate": after,
            "drop": round(before - after, 1),
        }
        for sid, (before, after) in dropped.items()
    ]
    results.sort(key=lambda r: -r["drop"])
    return results


# --------------------------------------------------------------------------
# Single-student analytics
# --------------------------------------------------------------------------
def get_student_summary(student):
    """Totals, rate and absence streaks for one student across all terms."""
    records = AttendanceRecord.objects.filter(student=student)
    agg = records.aggregate(
        total=Count("id"),
        present=_status_count(Status.PRESENT),
        absent=_status_count(Status.ABSENT),
        late=_status_count(Status.LATE),
        excused=_status_count(Status.EXCUSED),
    )
    statuses = list(records.order_by("date").values_list("status", flat=True))
    return {
        **agg,
        "rate": _rate(agg["present"] + agg["late"], agg["total"]),
        "current_streak": current_absence_streak(statuses),
        "longest_streak": longest_absence_streak(statuses),
    }


def get_student_monthly_breakdown(student):
    """Per-month status counts and rate for one student, oldest first."""
    rows = (
        AttendanceRecord.objects.filter(student=student)
        .annotate(month=TruncMonth("date"))
        .values("month")
        .annotate(
            total=Count("id"),
            present=_status_count(Status.PRESENT),
            absent=_status_count(Status.ABSENT),
            late=_status_count(Status.LATE),
            excused=_status_count(Status.EXCUSED),
        )
        .order_by("month")
    )
    return [{**row, "rate": _rate(row["present"] + row["late"], row["total"])} for row in rows]


def build_calendar_months(pairs):
    """Turn ``[(date, status)]`` into month grids for the calendar heatmap.

    Each month: ``{label, blank_cells, days: [{day, date, status|None}]}`` where
    ``blank_cells`` pads the first week so the grid starts on Monday.
    """
    by_date = dict(pairs)
    months = []
    for year, month in sorted({(d.year, d.month) for d in by_date}):
        first = date(year, month, 1)
        days = []
        for day in range(1, calendar.monthrange(year, month)[1] + 1):
            current = date(year, month, day)
            days.append({"day": day, "date": current, "status": by_date.get(current)})
        months.append(
            {
                "label": first.strftime("%B %Y"),
                "blank_cells": list(range(first.weekday())),
                "days": days,
            }
        )
    return months
