from django.urls import path

from . import views

app_name = "analytics"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("analytics/classes/", views.class_comparison, name="classes"),
    path("analytics/terms/", views.term_trends, name="terms"),
    path("analytics/insights/", views.insights, name="insights"),
]
