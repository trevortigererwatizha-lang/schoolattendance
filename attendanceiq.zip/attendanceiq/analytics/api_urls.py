from django.urls import path

from . import api_views

app_name = "api"

urlpatterns = [
    path("attendance/daily/", api_views.daily_attendance, name="daily"),
    path("analytics/class-comparison/", api_views.class_comparison, name="class_comparison"),
    path("analytics/term-trends/", api_views.term_trends, name="term_trends"),
]
