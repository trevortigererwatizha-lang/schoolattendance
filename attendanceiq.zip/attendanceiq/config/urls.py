"""Root URL configuration."""
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("analytics.api_urls")),
    path("students/", include("attendance.urls")),
    path("", include("analytics.urls")),
]
