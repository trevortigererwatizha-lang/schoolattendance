/* Chart helpers. Data is read from <script type="application/json"> blocks (json_script). */
(function () {
  "use strict";

  var PALETTE = ["#2563eb", "#dc2626", "#16a34a", "#d97706", "#7c3aed", "#0891b2", "#db2777", "#4b5563"];

  function readData(id) {
    var el = document.getElementById(id);
    return el ? JSON.parse(el.textContent) : null;
  }

  function make(canvasId, config) {
    var el = document.getElementById(canvasId);
    if (!el || typeof Chart === "undefined") { return null; }
    config.options = Object.assign({ responsive: true, maintainAspectRatio: false }, config.options || {});
    return new Chart(el, config);
  }

  function percentTicks(min) {
    return { min: min, max: 100, ticks: { callback: function (v) { return v + "%"; } } };
  }

  function axisFloor(values) {
    var nums = values.filter(function (v) { return v !== null && v !== undefined; });
    if (!nums.length) { return 0; }
    return Math.max(0, Math.floor(Math.min.apply(null, nums) / 10) * 10 - 10);
  }

  window.AIQ = {
    line: function (canvasId, dataId, label) {
      var d = readData(dataId);
      if (!d) { return null; }
      return make(canvasId, {
        type: "line",
        data: {
          labels: d.labels,
          datasets: [{
            label: label, data: d.values, borderColor: PALETTE[0], backgroundColor: PALETTE[0],
            tension: 0.25, pointRadius: d.values.length > 40 ? 0 : 3, fill: false
          }]
        },
        options: { scales: { y: percentTicks(axisFloor(d.values)) } }
      });
    },

    bar: function (canvasId, dataId, label) {
      var d = readData(dataId);
      if (!d) { return null; }
      var colors = d.below.map(function (b) { return b ? "#dc2626" : "#2563eb"; });
      return make(canvasId, {
        data: {
          labels: d.labels,
          datasets: [
            { type: "bar", label: label, data: d.values, backgroundColor: colors },
            {
              type: "line", label: "Threshold (" + d.threshold + "%)",
              data: d.labels.map(function () { return d.threshold; }),
              borderColor: "#6b7280", borderDash: [6, 4], pointRadius: 0, fill: false
            }
          ]
        },
        options: { scales: { y: percentTicks(0) } }
      });
    },

    multiLine: function (canvasId, dataId) {
      var d = readData(dataId);
      if (!d) { return null; }
      var all = [];
      d.series.forEach(function (s) { all = all.concat(s.rates); });
      return make(canvasId, {
        type: "line",
        data: {
          labels: d.labels,
          datasets: d.series.map(function (s, i) {
            var color = PALETTE[i % PALETTE.length];
            return {
              label: s.class_name, data: s.rates, borderColor: color, backgroundColor: color,
              tension: 0.2, spanGaps: true
            };
          })
        },
        options: { scales: { y: percentTicks(axisFloor(all)) } }
      });
    }
  };
})();
