/* Client-side column sorting for <table class="sortable">. Header cells may set data-type="number". */
(function () {
  "use strict";

  document.querySelectorAll("table.sortable").forEach(function (table) {
    var headers = Array.prototype.slice.call(table.querySelectorAll("thead th"));

    headers.forEach(function (th, index) {
      th.setAttribute("tabindex", "0");

      function sort() {
        var numeric = th.dataset.type === "number";
        var direction = th.getAttribute("aria-sort") === "ascending" ? "descending" : "ascending";
        headers.forEach(function (h) { h.removeAttribute("aria-sort"); });
        th.setAttribute("aria-sort", direction);

        var tbody = table.tBodies[0];
        var rows = Array.prototype.slice.call(tbody.rows);
        rows.sort(function (a, b) {
          var x = a.cells[index].textContent.trim();
          var y = b.cells[index].textContent.trim();
          var result = numeric ? parseFloat(x) - parseFloat(y) : x.localeCompare(y);
          return direction === "ascending" ? result : -result;
        });
        rows.forEach(function (row) { tbody.appendChild(row); });
      }

      th.addEventListener("click", sort);
      th.addEventListener("keydown", function (event) {
        if (event.key === "Enter" || event.key === " ") { event.preventDefault(); sort(); }
      });
    });
  });
})();
