"""Small request-parsing helpers shared by views."""


def get_int(request, key):
    """Return GET[key] as an int, or None if missing/invalid."""
    try:
        return int(request.GET.get(key, ""))
    except (TypeError, ValueError):
        return None


def get_float(request, key, default=None):
    """Return GET[key] as a float, or ``default`` if missing/invalid."""
    try:
        return float(request.GET.get(key, ""))
    except (TypeError, ValueError):
        return default
