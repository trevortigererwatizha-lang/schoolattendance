"""Optional site-wide login requirement (ATTENDANCE_REQUIRE_LOGIN=True)."""
from django.conf import settings
from django.contrib.auth.views import redirect_to_login


class LoginRequiredMiddleware:
    """Redirect anonymous users to the admin login when REQUIRE_LOGIN is on."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if settings.REQUIRE_LOGIN and not request.user.is_authenticated:
            exempt = ("/admin/", "/" + settings.STATIC_URL.lstrip("/"))
            if not request.path.startswith(exempt):
                return redirect_to_login(request.get_full_path(), settings.LOGIN_URL)
        return self.get_response(request)
