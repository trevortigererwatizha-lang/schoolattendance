"""Template context available on every page."""


def site(request):
    return {"SITE_NAME": "AttendanceIQ"}
