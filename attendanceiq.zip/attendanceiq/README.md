# AttendanceIQ — School Attendance Analytics Dashboard

A Django 5 application that helps school administrators and teachers analyse attendance
by class and academic term: interactive charts, filters, and automatic flags for students
and classes that need attention.

**Stack:** Python 3.11+, Django 5.1+, Bootstrap 5, Chart.js, SQLite (default) or PostgreSQL, pytest-django.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env               # optional; defaults work for local dev (Windows: copy)
python manage.py makemigrations attendance   # first run only: creates the migration files
python manage.py migrate
python manage.py seed_data
python manage.py runserver
```

Open <http://127.0.0.1:8000/>. To use the admin: `python manage.py createsuperuser`, then
visit `/admin/`.

> `makemigrations` is needed once because the migration files are generated from the
> models. Commit the generated `attendance/migrations/0001_initial.py` afterwards.

### Seed data

`python manage.py seed_data` creates 1 school, 3 terms, 6 classrooms (one teacher each),
25–30 students per class and 90 school days of attendance per term (weekdays only), using a
90 / 5 / 3 / 2 % present / absent / late / excused distribution. A handful of students and two
classes are deliberately weaker so the Insights page has something to flag. The newest term ends
on the most recent weekday, so "today" always has data.

Options: `--reset` (wipe and re-seed), `--seed N` (random seed, default 42),
`--school-days N` (days per term, default 90).

### PostgreSQL

```bash
pip install "psycopg[binary]"
# in .env
DATABASE_URL=postgres://user:password@localhost:5432/attendanceiq
```

### Tests

```bash
pytest
```

## Configuration (`.env`)

| Variable | Default | Purpose |
|---|---|---|
| `SECRET_KEY` | insecure dev key | Required when `DEBUG=False` |
| `DEBUG` | `True` | Set `False` in production |
| `ALLOWED_HOSTS` | `localhost,127.0.0.1` | Comma separated |
| `DATABASE_URL` | SQLite file | Any URL understood by `dj-database-url` |
| `ATTENDANCE_REQUIRE_LOGIN` | `False` | `True` redirects anonymous users to the admin login |
| `ATTENDANCE_CLASS_THRESHOLD` | `80` | Highlight threshold on the class comparison page |
| `INSIGHT_LOW_CLASS_RATE` | `75` | Insights: class rate flag |
| `INSIGHT_CONSECUTIVE_ABSENCES` | `3` | Insights: flag when MORE than this many in a row |
| `INSIGHT_DROP_POINTS` | `20` | Insights: drop vs previous term, in percentage points |

Student attendance data is personal data. Turn on `ATTENDANCE_REQUIRE_LOGIN` (and serve over HTTPS)
for any real deployment.

## How attendance is calculated

`rate = (Present + Late) / all records × 100`, rounded to one decimal. Late students attended;
absent and excused students did not. A "consecutive absence" is a run of `ABSENT` records in date
order (school days), so weekends and holidays do not break a streak. "Dropped >20%" means a drop of
more than 20 **percentage points** versus the previous term.

## Pages

| URL | Name | What it shows |
|---|---|---|
| `/` | `analytics:dashboard` | Student/class totals, term attendance rate, today's (or latest day's) present/absent/late/excused counts, daily-rate line chart. Term and class filters. |
| `/analytics/classes/` | `analytics:classes` | Bar chart of attendance per class for a term, sortable table (students, %, absences, late), classes under a configurable threshold highlighted (`?threshold=`). |
| `/analytics/terms/` | `analytics:terms` | Multi-line chart of attendance per class across terms, filter by grade level or classes, raw-percentage table. |
| `/students/` | `attendance:student_list` | Searchable, paginated student list with overall rate. |
| `/students/<id>/` | `attendance:student_detail` | Rate, current/longest absence streak, calendar heatmap, monthly breakdown + chart, recent records. |
| `/analytics/insights/` | `analytics:insights` | Students with >3 consecutive absences or <75% attendance, students whose rate dropped >20 points, classes <75%; all link to detail pages. |

Every chart has an `aria-label` and a table alternative on the same page.

## JSON API

- `GET /api/attendance/daily/?term=<id>&classroom=<id>`
- `GET /api/analytics/class-comparison/?term=<id>`
- `GET /api/analytics/term-trends/?classes=<id,id>`

`term` defaults to the current (or latest) term; omit `classes`/`classroom` for all classes.

## Project layout

```
config/       settings, root urls, wsgi/asgi
core/         shared utilities, context processor, optional login middleware
attendance/   models, admin, student pages, seed_data command
analytics/    services/analytics.py (pure query functions), views, JSON API, tests
templates/    base layout (navbar + sidebar) and page templates
static/       app.css, charts.js (Chart.js helpers), app.js (table sorting)
```

The service functions in `analytics/services/analytics.py` aggregate in the database with
`Count(..., filter=Q(...))`. The one place Python looks at ordered rows is consecutive-absence
detection, and only for the small set of students whose absence count or rate makes them candidates.

## Deployment notes

`gunicorn config.wsgi` with `DEBUG=False`, a real `SECRET_KEY`, `ALLOWED_HOSTS`, a PostgreSQL
`DATABASE_URL`, and `python manage.py collectstatic`. WhiteNoise serves static files.
Chart.js and Bootstrap load from the jsDelivr CDN; vendor them into `static/` for offline use.
